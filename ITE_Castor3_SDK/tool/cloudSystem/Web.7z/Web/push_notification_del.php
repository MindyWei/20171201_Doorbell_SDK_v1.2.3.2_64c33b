<?php session_start(); ?>
<?php
    require_once("common.php");
    
    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    $item_no = implode("," , $_POST['del_item_no']);
    if (!empty($item_no)) {
    	require_once("DB_config.php");
    	require_once("DB_class.php");
	/////////////////////////////////////////////////////////////////////////
    	$db = new DB();
    	$db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    	/////////////////////////////////////////////////////////////////////////
        if (!$db->check_priv($_SESSION['user_id'], 'priv_push_notification')) {
            $db->close();
            include('access_denied.php');
            return;
        }
        /////////////////////////////////////////////////////////////////////////
		$sql = "DELETE FROM device_token WHERE id in (".$item_no.")";
    	$db->query($sql);
    	/////////////////////////////////////////////////////////////////////////
    }

    if (!isset($_GET["page"])) {
    	$page = 1;
    } else {
    	$page = intval($_GET["page"]);
    }
    /////////////////////////////////////////////////////////////////////////
    $db->close();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
</head>
<body>
<script type="text/javascript">
    $(document).ready(function () {
        var url = 'push_notification_list.php?page=<?php echo $page; ?>';
        window.location.href = url;
    });
</script>
</body>
</html>