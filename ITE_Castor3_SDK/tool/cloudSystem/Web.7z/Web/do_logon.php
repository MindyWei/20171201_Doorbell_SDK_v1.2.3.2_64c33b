<?php session_start(); ?>
<?php
    require_once("common.php");

    if (check_logon()) {
        echo "1";
        return;
    }
?>
<?php
    require_once("DB_config.php");
    require_once("DB_class.php");
    /////////////////////////////////////////////////////////////////////////
    $db = new DB();
    $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    /////////////////////////////////////////////////////////////////////////
    $account_id = $_POST["account_id"];
    $account_id = $db->escape_string($account_id);
    $account_password = $_POST["account_password"];
    $account_password2 = $db->escape_string($account_password);
    $sql = "SELECT * FROM account WHERE account_id='$account_id' AND account_password='$account_password2'";
    $db->query($sql);

    if (($result = $db->fetch_array())) {
        if ($result['account_password'] == $account_password) {
            $_SESSION['user_id'] = $result['id'];;
            $_SESSION['user_account_id'] = $result['account_id'];
            $_SESSION['user_account_name'] = $result['name'];

            echo "1";
        } else {
            echo "0";
        }
    } else {
        echo "0";
    }

    $db->close();
?>
