<?php session_start(); ?>
<?php
    require_once("common.php");

    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    require_once("DB_config.php");
    require_once("DB_class.php");

	$db = new DB();
	$db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
	/////////////////////////////////////////////////////////////////////////
	if (!$db->check_priv($_SESSION['user_id'], 'priv_address_book')) {
		$db->close();
		include('access_denied.php');
		return;
	}

	//$db->close();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
    <link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>	   
<?php
	$uploaddir = './upload/';
	$uploadfile = $uploaddir . basename($_FILES['file']['name']);
	echo '<pre>';

	if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) {
    	//echo "File is valid, and was successfully uploaded.\n";
    	echo "<a href='address_book.php'><font color='blue' size='6'><u>回社區地址表</u></font></a>";
	} else {
    	echo "Possible file upload attack!(chmod 777 upload...)\n";
	}

	print "</pre>";
	
	if (file_exists($uploadfile)) {
		$xml = simplexml_load_file($uploadfile);
		//print_r($xml);
		$gateway = $xml->comm['gateway'];
		$submask = $xml->comm['submask'];
		echo "gateway:".$gateway."<BR>";
		echo "submask:".$submask."<BR>";
		
		$db->delete_all_address_book();
		$db->update_address_book_gateway($gateway);
		$db->update_address_book_submask($submask);
		
		for ($i = 0 ; $i < 99999 ; $i++) {
			if (is_null($xml->dev[$i])) break;

			$ty = $xml->dev[$i]['ty'];
			$ro = $xml->dev[$i]['ro'];
			$alias = $xml->dev[$i]['alias'];
			$ip = $xml->dev[$i]['ip'];
			$mc = $xml->dev[$i]['mc'];
			$group = $xml->dev[$i]['group'];
			$id = $xml->dev[$i]['id'];
			$pw = $xml->dev[$i]['pw'];
			
			echo 
				"(".($i + 1)."): ".
				"ty='".$ty."' ".
				"ro='".$ro."' ".
				"alias='".$alias."' ".
				"ip='".$ip."' ".
				"group='".$group."' ".
				"mc='".$mc."' ".
				"id='".$id."' ".
				"pw='".$pw."'<BR>";

			$db->insert_address_book(
				$ty,
				$alias,
				$ro,
				$group,
				$mc,
				$ip,
				$id,
				$pw
				);
		}
		
		$db->update_address_book_version();
		$db->close();
	} else {
		echo $uploadfile." not found.<br>";
	}
	
	echo "<br><a href='address_book.php'><font color='blue' size='6'><u>回社區地址表</u></font></a>";
?>
</body>
</html>