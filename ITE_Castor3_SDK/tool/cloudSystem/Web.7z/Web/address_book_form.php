<?php session_start(); ?>
<?php
    require_once("common.php");

    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    /////////////////////////////////////////////////////////////////////////
    if (!isset($_GET["page"])) {
    	$page = 1;
    } else {
    	$page = intval($_GET["page"]);
    }
    
    $title_desc = "社區地址表";
    $edit_mode_id_not_found = false;
    /////////////////////////////////////////////////////////////////////////
    if (isset($_GET["id"])) {
    	require_once("DB_config.php");
    	require_once("DB_class.php");
	/////////////////////////////////////////////////////////////////////////
    	$db = new DB();
        $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
        /////////////////////////////////////////////////////////////////////////
        if (!$db->check_priv($_SESSION['user_id'], 'priv_address_book')) {
            $db->close();
            include('access_denied.php');
            return;
        }
        /////////////////////////////////////////////////////////////////////////
        $id = $_GET["id"];
    	$sql = "SELECT * FROM address_book WHERE id=".$db->escape_string($id);
    	$db->query($sql);
    	
    	if (($result = $db->fetch_array())) {
            $dbf_ty = $result['ty'];
            $dbf_alias = $result['alias'];
            $dbf_ro = $result['ro'];
            $dbf_group = $result['_group'];
            $dbf_mc = $result['mc'];
            $dbf_ip = $result['ip'];
            $dbf_user_id = $result['user_id'];
            $dbf_user_pwd = $result['user_pwd'];
    	} else {
            $edit_mode_id_not_found = true;
    	}
    	
    	$db->close();
    }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
    <link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>	   
<form id="form" method="post" enctype="multipart/form-data">
    <table width="100%" align="left" cellpadding="5px" cellspacing="0" style="margin-top:2px; margin-bottom: 10px; border:2px #D8D8D8 solid;padding:5px;" rules="all" cellpadding="5">
        <tr>
            <td colspan='2'><h1><?php echo $title_desc; ?></h1></td>
        </tr>
        <tr>
            <td align="center">編號</td>
            <td>
<?php 
    if (empty($id)) {
        echo "<font style='color:#0000FF;'>系統自動編號</font>";
    } else {
        echo $id;
        echo '<input type="hidden" id="dbf_id" name="dbf_id" value="'.$id.'"></input>';
    }
?>
            </td>
        </tr>
        <tr>
            <td align="center"  valign="top" nowrap><font style='color:red;'>*</font>設備類別</td>
            <td>
                <input type="text" id="dbf_ty" name="dbf_ty" maxlength="3" value="<?php echo $dbf_ty; ?>" style="width:100%;"></input>
                <br>
                0：ICM伺服器。1：門鈴機。2：單元門口機。<br>
                3：棟門口機。4：社區門口機（圍牆機）。<br>
                5：室內機。6：管理中心機。7：帶sd卡的室內機。<br>
                8：手機。 9：緊急對講機。10：IP Camera
            </td>
        </tr>
        <tr>
            <td align="center" valign="top" nowrap>設備別名</td>
            <td>
                <input type="text" id="dbf_alias" name="dbf_alias" maxlength="100" value="<?php echo $dbf_alias; ?>" style="width:100%;"></input>
            </td>
        </tr>
        <tr>
            <td align="center" valign="top" nowrap>設備完整地址</td>
            <td>
                <input type="text" id="dbf_ro" name="dbf_ro" maxlength="100" value="<?php echo $dbf_ro; ?>" style="width:100%;"></input>
            </td>
        </tr>
        <tr>
            <td align="center" valign="top" nowrap>設備組ip</td>
            <td>
                <input type="text" id="dbf_group" name="dbf_group" maxlength="100" value="<?php echo $dbf_group; ?>" style="width:100%;"></input>
            </td>
        </tr>
		<tr>
            <td align="center" valign="top" nowrap>設備MAC地址</td>
            <td>
                <input type="text" id="dbf_mc" name="dbf_mc" maxlength="50" value="<?php echo $dbf_mc; ?>" style="width:100%;"></input>
            </td>
        </tr>
        <tr>
            <td align="center" valign="top" nowrap>設備ip</td>
            <td>
                <input type="text" id="dbf_ip" name="dbf_ip" maxlength="50" value="<?php echo $dbf_ip; ?>" style="width:100%;"></input>
            </td>
        </tr>
        <tr>
            <td align="center" valign="top" nowrap>登入帳號</td>
            <td>
                <input type="text" id="dbf_user_id" name="dbf_user_id" maxlength="50" value="<?php echo $dbf_user_id; ?>" style="width:100%;"></input>
            </td>
        </tr>
        <tr>
            <td align="center" valign="top" nowrap>登入密碼</td>
            <td>
                <input type="text" id="dbf_user_pwd" name="dbf_user_pwd" maxlength="50" value="<?php echo $dbf_user_pwd; ?>" style="width:100%;"></input>
            </td>
        </tr>
        <tr>
            <td style='text-align: center;' colspan='2'>
                <button type="button" id="submit_button" name="submit_button" style="margin-right: 50px;">確定存檔</button>
                <button type="button" id="cancel_button" name="cancel_button">回上一頁</button>
            </td>
        </tr>
    </table>
</form>
<script type="text/javascript">
    $(document).ready(function () {
<?php 
    if ($edit_mode_id_not_found) {
        echo "var url = 'address_book.php?page=<?php echo $page; ?>';";
        echo "window.location.href = url;";
    }
?>
        $("#submit_button").click(function() {
            if (!$.trim($("#dbf_ty").val()).length) {
                alert('請輸入[設備類別]');
                $("#dbf_ty").focus();
                return false;
            }

            $("#submit_button").html('處理中請稍候...');
            $("#submit_button").attr('disabled', true);
            $("#cancel_button").attr('disabled', true);

            $("#form").attr("action", "address_book_update.php?page=<?php echo $page; ?>");
            $("#form").submit();
            return true;
        });

        $("#cancel_button").click(function() {
            window.history.back();
        });
    });
</script>
</body>
</html>