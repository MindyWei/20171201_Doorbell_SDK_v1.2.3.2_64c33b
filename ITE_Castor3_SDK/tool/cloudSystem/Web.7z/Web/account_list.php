<?php session_start(); ?>
<?php
    require_once("common.php");
    
    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    require_once("DB_config.php");
    require_once("DB_class.php");
    /////////////////////////////////////////////////////////////////////////
    $db = new DB();
    $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    /////////////////////////////////////////////////////////////////////////
    if (!$db->check_priv($_SESSION['user_id'], 'priv_account')) {
        $db->close();
        include('access_denied.php');
        return;
    }
    /////////////////////////////////////////////////////////////////////////
    $sql = "SELECT *,DATE_FORMAT(modi_date,'%Y-%m-%d') AS _modi_date FROM account";
    if (isset($_POST["filter_keyword"])) {
    	$filter_keyword = $_POST["filter_keyword"];
    }
    $filter_keyword = $db->escape_string($filter_keyword);
    if (!empty($filter_keyword)) {
    	$sql = $sql." WHERE ".
                    "account_id like '%".$filter_keyword."%' OR ".
                    "name like '%".$filter_keyword."%' OR ".
                    "job_name like '%".$filter_keyword."%' ";
    }
    $db->query($sql);
    /////////////////////////////////////////////////////////////////////////
    if (!isset($_GET["page"])) {
        $page = 1;
    } else {
        $page = intval($_GET["page"]);
    }
    
    $title_desc = "使用者權限管理";
    $items = $db->get_num_rows();//mysql_affected_rows();
    $items_per_page = 10;
    $colspan = 8;
    $index_pages = 10;
    $this_page = "account_list.php";
    $pages = ceil($items / $items_per_page);
    $select_start = ($page - 1) * $items_per_page;
    $sql = $sql.
    	   " ORDER BY name  
    	     LIMIT $select_start , $items_per_page ";
    $db->query($sql);
    /////////////////////////////////////////////////////////////////////////
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
    <link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>
<form id="form" method="post">
    <table width="100%" align="left" cellpadding="5px" cellspacing="0" style="margin-top:2px; margin-bottom: 10px; border:2px #D8D8D8 solid;padding:5px;" rules="all" cellpadding="5">
        <tr>
            <td colspan=<?php echo $colspan; ?>><h1><?php echo $title_desc; ?></h1></td>
        </tr>
        <tr>
            <td colspan='<?php echo $colspan; ?>'>
                <table style='width:100%'>
                    <tr>
                        <td align='left'>
                            <button type="button" id="new_item_button">新增</button>
                        </td>
                        <td align='right' nowrap>
                            ◎請輸入
                            <input type="text" id="filter_keyword" name="filter_keyword" value="<?php echo $_POST["filter_keyword"]; ?>"  placeholder="關鍵字"></input>
                            <button type="button" id="filter_item_button">查詢</button>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    	<tr style='text-align: center; background-color: #F2F2F2; color: #000000;'>
            <td nowrap><button type="button" id="del_item_button" name="del_item_button">刪除</button></td>
            <td nowrap>&nbsp;</td>
            <td nowrap>項次</td>
            <td nowrap>使用者姓名</td>
            <td nowrap>使用者帳號</td>
            <td nowrap>職務</td>
            <td nowrap>備註</td>
            <td nowrap>最後修改日期</td>
        </tr>
<?php
	$item_count = ($page - 1) * $items_per_page;
	
	while(($result = $db->fetch_array())) {
            $db_pk = $result['id'];

            $item_count++;

            echo '<tr style="background-color: ';
            if (($item_count % 2) == 0) {
                echo '#EFFBFB; color: #000000;';
            } else {
                echo '#FFFFFF; color: #000000;';
            }
            echo '">';
        
            echo '<td align="center" valign="top">';
            echo '<input type="checkbox" ';
            if ($result['account_id'] == 'admin') {
                echo ' disabled ';
            }
            echo 'id="del_checkbox'.$item_count.'" name="del_item_no[]" value="'.$db_pk.'" ></input>';
            echo '</td>';
            echo '<td align="center" valign="top" nowrap>';
            echo '<button type="button" id="edit_item_button" class="editInput" value="'.$db_pk.'">編輯</button>';
            echo '</td>';
            echo '<td align="center" valign="top">';
            echo $item_count;
            echo '</td>';
            echo '<td valign="top">';
            echo filter_string($result['name'], $filter_keyword);
            echo '</td>';
            echo '<td valign="top">';
            echo filter_string($result['account_id'], $filter_keyword);
            echo '</td>';
            echo '<td valign="top">';
            echo filter_string($result['job_name'], $filter_keyword);
            echo '</td>';
             echo '<td valign="top">';
            echo filter_string($result['memo'], $filter_keyword);
            echo '</td>';
            echo '<td align="center" valign="top" nowrap>';
            echo $result['_modi_date'];
            echo '</td>';
		
            echo '</tr>';
	}
	
	/////////////////////////////////////////////////////////////////////////
	$footer_bar_begin = '<tr style="text-align: center; background-color: #F2F2F2; color: #000000;"><td colspan='.$colspan.'>';
	$footer_bar_end = '</td></tr>';
	
	if ($items > 0) {
            $start_index_page = ((ceil($page / $index_pages) - 1) * $index_pages) + 1;
            $end_index_page = $start_index_page + $index_pages;
            $index_page_count = 1;
            echo $footer_bar_begin;
            echo '目前共有&nbsp;'.$items.'&nbsp;筆&nbsp;&nbsp;-&nbsp;&nbsp;';
            if ($page > 1) {
                $prev_page = $page - 1;
                echo "<a style='color:#000000;' href='javascript:goPage($prev_page);' title='前一頁'>&lt;&lt;</a>&nbsp;&nbsp;";
            }
            for ($i = $start_index_page ; $i <= $pages ; $i++) {
                if ($i == $start_index_page && $i > 1) {
                    $prev_page_seg = $start_index_page - 1;
                    echo "&nbsp;<a style='color:#000000;' href='javascript:goPage($prev_page_seg);' title='更多頁...'>&nbsp;...&nbsp;</a>&nbsp;";
                }
                if ($index_page_count++ > $index_pages) {
                    echo "&nbsp;<a style='color:#000000;' href='javascript:goPage($i);' title='更多頁...'>&nbsp;...&nbsp;</a>&nbsp;";
                    break;
                }

                if ($i != $page) echo "&nbsp;<a href='javascript:goPage($i);'>";
                if ($i == $page) {
                    echo "<font style='color:#FF0000;'>&nbsp;$i&nbsp;</font>";
                } else {
                    echo "<font style='color:#000000;'>&nbsp;$i&nbsp;</font>";
                }
                if ($i != $page) echo '</a>&nbsp;';
            }
            if ($page < $pages) {
                $next_page = $page + 1;
                echo "&nbsp;&nbsp;<a style='color:#000000;' href='javascript:goPage($next_page);' title='下一頁'>&gt;&gt;</a>";
            }
            echo $footer_bar_end;
	} else {
            echo '<tr><td colspan='.$colspan.' align=center>無&nbsp;&nbsp;資&nbsp;&nbsp;料</td></tr>';
            echo $footer_bar_begin;
            echo '&nbsp;';
            echo $footer_bar_end;
	}
        
        $db->close();
?>
    </table>
</form>
<script type="text/javascript">
    function goPage(page) {
        var keyword = $.trim($("#filter_keyword").val());
        $("#filter_keyword").val(keyword);
        $("#form").attr("action", "<?php echo $this_page; ?>?page=" + page);
        $("#form").submit();
    }
	
    $(document).ready(function () {
        $("#del_item_button").click(function() {
            if (!confirm('確定刪除?')) return;

            var items = new Array();
            $('input[name="del_item_no"]:checkbox:checked').each(function(i) {
                    items[i] = this.value;
            });
            $("#form").attr("action", "account_del.php?page=<?php echo $page; ?>");
            $("#form").submit();
        });

        $("#filter_item_button").click(function() {
            var keyword = $.trim($("#filter_keyword").val());
            $("#filter_keyword").val(keyword);
            $("#form").attr("action", "<?php echo $this_page; ?>");
            $("#form").submit();
        });

        $("#new_item_button").click(function() {
            $("#form").attr("action", "account_form.php?page=<?php echo $page; ?>");
            $("#form").submit();
        });

        $('.editInput').bind('click', function() {
            $("#form").attr("action", "account_form.php?id=" + $(this).attr("value") + "&page=<?php echo $page; ?>");
            $("#form").submit();
        });
    });
</script>
</body>
</html>