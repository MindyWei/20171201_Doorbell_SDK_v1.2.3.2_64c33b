<?php session_start(); ?>
<?php
    require_once("common.php");
    
    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    /////////////////////////////////////////////////////////////////////////
    if (!isset($_GET["page"])) {
    	$page = 1;
    } else {
    	$page = intval($_GET["page"]);
    }
    
    $title_desc = "個人資料管理";
    $edit_mode_id_not_found = false;
    /////////////////////////////////////////////////////////////////////////
    require_once("DB_config.php");
    require_once("DB_class.php");
    /////////////////////////////////////////////////////////////////////////
    $db = new DB();
    $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    /////////////////////////////////////////////////////////////////////////
    $sql = "SELECT * FROM account WHERE id=".$_SESSION['user_id'];
    $db->query($sql);

    if (($result = $db->fetch_array())) {
        $dbf_account_id = $result['account_id'];
        $dbf_account_password = $result['account_password'];
        $dbf_name = $result['name'];
        $dbf_email = $result['email'];
        $dbf_job_name = $result['job_name'];
        $dbf_phone = $result['phone'];
        $dbf_mobile_phone = $result['mobile_phone'];
    } else {
        $edit_mode_id_not_found = true;
        die("資料錯誤!!!");
    }

    $db->close();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
    <link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>
<form id="form" method="post" enctype="multipart/form-data">
    <table width="100%" align="left" cellpadding="5px" cellspacing="0" style="margin-top:2px; margin-bottom: 10px; border:2px #D8D8D8 solid;padding:5px;" rules="all" cellpadding="5">
        <tr>
            <td colspan='2'><h1><?php echo $title_desc; ?></h1></td>
        </tr>
        <tr>
            <td align="center" nowrap><font style='color:red;'>*</font>使用者姓名</td>
            <td>
                <input type="text" id="dbf_name" name="dbf_name" maxlength="100" size="80" value="<?php echo $dbf_name; ?>"></input>
            </td>
        </tr>
        <tr>
            <td align="center" nowrap><font style='color:red;'>*</font>使用者帳號</td>
            <td>
                <input type="text" id="dbf_account_id" name="dbf_account_id" maxlength="50" size="80" value="<?php echo $dbf_account_id; ?>"></input>
            </td>
        </tr>
        <tr>
            <td align="center" nowrap><font style='color:red;'>*</font>密碼</td>
            <td>
                <input type="password" id="dbf_account_password" name="dbf_account_password" maxlength="50" size="80" value="<?php echo $dbf_account_password; ?>"></input>
            </td>
        </tr>
        <tr>
            <td align="center" nowrap>電子郵件</td>
            <td>
                <input type="text" id="dbf_email" name="dbf_email" maxlength="150" size="80" value="<?php echo $dbf_email; ?>"></input>
            </td>
        </tr>
        <tr>
            <td align="center" nowrap>職稱</td>
            <td>
                <input type="text" id="dbf_job_name" name="dbf_job_name" maxlength="50" size="80" value="<?php echo $dbf_job_name; ?>"></input>
            </td>
        </tr>
        <tr>
            <td align="center" nowrap>電話</td>
            <td>
                <input type="text" id="dbf_phone" name="dbf_phone" maxlength="30" size="40" value="<?php echo $dbf_phone; ?>"></input>
            </td>
        </tr>
        <tr>
            <td align="center" nowrap>手機</td>
            <td>
                <input type="text" id="dbf_mobile_phone" name="dbf_mobile_phone" maxlength="30" size="40" value="<?php echo $dbf_mobile_phone; ?>"></input>
            </td>
        </tr>
        <tr>
            <td style='text-align: center;' colspan='2'>
                <button type="button" id="submit_button" name="submit_button" style="margin-right: 50px;">確定存檔</button>
                <button type="button" id="cancel_button" name="cancel_button">回上一頁</button>
            </td>
        </tr>
    </table>
</form>
<script type="text/javascript">
    $(document).ready(function () {
<?php 
	if ($edit_mode_id_not_found) {
            echo "var url = 'welcome.html';";
            echo "window.location.href = url;";
	}
?>
        $("#submit_button").click(function() {
            if (!$.trim($("#dbf_name").val()).length) {
                alert('請輸入[使用者姓名]');
                $("#dbf_name").focus();
                return false;
            }
            if (!$.trim($("#dbf_account_id").val()).length) {
                alert('請輸入[使用者帳號]');
                $("#dbf_account_id").focus();
                return false;
            }
            if (!$.trim($("#dbf_account_password").val()).length) {
                alert('請輸入[密碼]');
                $("#dbf_account_password").focus();
                return false;
            }
     		
            $("#submit_button").html('處理中請稍候...');
            $("#submit_button").attr('disabled', true);
            $("#cancel_button").attr('disabled', true);

            $("#form").attr("action", "account_info_update.php?page=<?php echo $page; ?>");
            $("#form").submit();
            return true;
	});
		
        $("#cancel_button").click(function() {
            window.history.back();
        });
    });
</script>
</body>
</html>