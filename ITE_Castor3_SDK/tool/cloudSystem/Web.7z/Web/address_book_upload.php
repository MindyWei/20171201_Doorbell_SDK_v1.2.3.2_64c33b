<?php session_start(); ?>
<?php
    require_once("common.php");

    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    $title_desc = "匯入社區地址表";
    
    require_once("DB_config.php");
    require_once("DB_class.php");

	$db = new DB();
	$db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
	/////////////////////////////////////////////////////////////////////////
	if (!$db->check_priv($_SESSION['user_id'], 'priv_address_book')) {
		$db->close();
		include('access_denied.php');
		return;
	}

	$db->close();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
    <link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>	   
<form id="form" method="post" enctype="multipart/form-data" action="do_address_book_upload.php">
    <table width="100%" align="left" cellpadding="5px" cellspacing="0" style="margin-top:2px; margin-bottom: 10px; border:2px #D8D8D8 solid;padding:5px;" rules="all" cellpadding="5">
        <tr>
            <td colspan='2'><h1><?php echo $title_desc; ?></h1></td>
        </tr>
        <tr>
            <td align="center">檔案名稱 : <input type="file" name="file" id="file" /></td>
		</tr>
		<tr>
            <td align="center"><input type="submit" name="submit_button" id="submit_button" value="開始匯入" disabled /></td>
		</tr>
    </table>
</form>
<script type="text/javascript">
    $(document).ready(function () {
    	$('input:file').on("change", function() {
    		$('input:submit').prop('disabled', !$(this).val()); 
		});
    });
</script>
</body>
</html>