<?php session_start(); ?>
<?php
    require_once("common.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<?php
    if (!check_logon()) {
        echo "<script language=\"javascript\">window.open(\"logon.php\",\"_parent\");</script>";
    }
?>
<frameset rows="*" cols="180,*" framespacing="0" frameborder="NO" border="0">
    <frame src="side_menu.php" name="left" scrolling="auto" noresize id="left">
    <frame src="welcome.html" name="main" scrolling="auto" noresize id="main"
          style="background-image: url(images/background3x.jpg); background-repeat: no-repeat; background-attachment: fixed; background-position: top; background-size: 100% 100%;">
</frameset>
<noframes>
	<body>
	</body>
</noframes>
</html>