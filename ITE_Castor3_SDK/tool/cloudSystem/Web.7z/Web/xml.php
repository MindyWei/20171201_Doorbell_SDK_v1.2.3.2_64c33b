<?php
	$file = "/Users/hsu/SYSCODE/ITE/Intercom/Doc/addressbook.xml";
	if (file_exists($file)) {
		$xml = simplexml_load_file($file);
		/*
		for ($i=0; $i < count($xml); $i++) {
			print($xml[$i]);
			print('\n');
		}
		*/
		print_r($xml);
		echo 'gateway:'.$xml->comm['gateway']."\n";
		echo 'submask:'.$xml->comm['submask']."\n";
		echo 'dev count:'.count($xml->dev->children())."\n";

		for ($i = 0 ; $i < 30 ; $i++) {
		//<dev ty="2" ro="01-02-01-00-00-01" alias="單元門口機11" ip="192.168.191.199" group="239.255.42.88" mc="010000000001" />
			if (is_null($xml->dev[$i])) {
				break;
			}
			echo 
				"(".$i."): ".
				"ty='".$xml->dev[$i]['ty']."' ".
				"ro='".$xml->dev[$i]['ro']."' ".
				"alias='".$xml->dev[$i]['alias']."' ".
				"ip='".$xml->dev[$i]['ip']."' ".
				"group='".$xml->dev[$i]['group']."' ".
				"mc='".$xml->dev[$i]['mc']."' ".
				"id='".$xml->dev[$i]['id']."' ".
				"pw='".$xml->dev[$i]['pw']."'\n";
		}		
//		echo 'name:'.$xml[0].getName()."\n";
	}
	
?>
