<?php session_start(); ?>
<?php
    require_once("common.php");

    if (!check_logon()) {
        include('logon.php');
        return;
    }
	
    require_once("DB_config.php");
    require_once("DB_class.php");
    /////////////////////////////////////////////////////////////////////////
    $db = new DB();
    $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    /////////////////////////////////////////////////////////////////////////
    $sql = "SELECT * FROM account WHERE id=".$_SESSION['user_id'];
    $db->query($sql);

    if (($result = $db->fetch_array())) {
        $dbf_priv_push_notification = $result['priv_push_notification'];
        $dbf_priv_address_book = $result['priv_address_book'];
        $dbf_priv_account = $result['priv_account'];
    } else {
        $edit_mode_id_not_found = true;
    }

    $db->close();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body bgcolor="#336699">
<table width="168" border="0" align="center">
    <!--
    <tr>
    <td height="25" bgcolor="#e7e2de" nowrap>
        <div align="center"><?php echo date('Y-m-d H:i');?></div>
    </td>
    </tr>
    -->
    <tr>
    <td height="25" bgcolor="#e7e2de">
        <div align="center">登入者 : <font color="#FF0000"><strong><?php echo $_SESSION['user_account_id']; ?></strong></font></div>
    </td>
    </tr>
    <tr>
        <td height="30" bgcolor="#e7e2de"> 
            <div align="center"><strong>系 統 管 理 區</strong></div>
        </td>
    </tr>
</table>

<table width="168" align="center" cellpadding="9" cellspacing="1" bordercolor="#999999">
<?php

    if ($dbf_priv_push_notification == 1) {
        echo '
                <tr>
                        <td height="9" bgcolor="#003366">
                                <img src="arrow_orange_1.gif" width="10" height="11" align="absmiddle">
                                        <a href="push_notification_list.php" target="main">推播管理</a>
                        </td>
                </tr>
        ';
    }
    
    if ($dbf_priv_address_book == 1) {
        echo '
                <tr>
                        <td height="9" bgcolor="#003366">
                                <img src="arrow_orange_1.gif" width="10" height="11" align="absmiddle">
                                        <a href="address_book.php" target="main">社區地址表</a>
                        </td>
                </tr>
        ';
    }

    if ($dbf_priv_account == 1) {
        echo '
                <tr>
                        <td bgColor=#003366 height=20>
                                <img src="arrow_orange_1.gif" width="10" height="11" align="absmiddle">
                                        <a href="account_list.php" target="main">使用者權限管理</a>
                                </td>
                </tr>
        ';
    }
?>
    <tr>
    <td height="20" bgcolor="#000232">
        <img src="arrow_orange_1.gif" width="10" height="11" align="absmiddle">
        <a href="account_info_form.php" target="main">密碼修改</a>
    </td>
    </tr>
    <tr>
    <td height="20" bgcolor="#000232">
        <img src="arrow_orange_1.gif" width="10" height="11" align="absmiddle">
        <a href="logout.php" target="_parent">登出管理介面</a>
    </td>
    </tr>
</table>
</body>
</html>