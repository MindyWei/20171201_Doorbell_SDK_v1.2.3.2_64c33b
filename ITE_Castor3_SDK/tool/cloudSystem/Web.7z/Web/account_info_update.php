<?php session_start(); ?>
<?php
    require_once("common.php");
    
    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    $process_ok = false;

    if (!isset($_POST["dbf_id"])) {
        $edit_mode = 2;
    }
    /////////////////////////////////////////////////////////////////////////
    require_once("DB_config.php");
    require_once("DB_class.php");
    /////////////////////////////////////////////////////////////////////////
    $db = new DB();
    $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    /////////////////////////////////////////////////////////////////////////
    if ($edit_mode == 2) $dbf_id = $db->escape_string($_POST['dbf_id']);
    $dbf_account_id = $db->escape_string($_POST['dbf_account_id']);
    $dbf_account_password = $db->escape_string($_POST['dbf_account_password']);
    $dbf_name = $db->escape_string($_POST['dbf_name']);
    $dbf_email = $db->escape_string($_POST['dbf_email']);
    $dbf_job_name = $db->escape_string($_POST['dbf_job_name']);
    $dbf_phone = $db->escape_string($_POST['dbf_phone']);
    $dbf_mobile_phone = $db->escape_string($_POST['dbf_mobile_phone']);

    $sql = 
            "UPDATE account SET ".
            "account_id='$dbf_account_id',".
            "account_password='$dbf_account_password',".
            "name='$dbf_name',".
            "email='$dbf_email',".
            "job_name='$dbf_job_name',".
            "phone='$dbf_phone',".
            "mobile_phone='$dbf_mobile_phone',".
            "modi_date=now() ".
            "WHERE id=".$_SESSION['user_id'];

    if ($db->query($sql)) {
        echo "<p style='font-size:30px; width:100%; text-align:center; margin-top:50px;'>變更完成</p>";
        $process_ok = true;
    } else {
        die('系統錯誤!!!');
    }
    /////////////////////////////////////////////////////////////////////////
    $db->close();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
</head>
<body>
<script type="text/javascript">
    $(document).ready(function () {

    });	
</script>
</body>
</html>