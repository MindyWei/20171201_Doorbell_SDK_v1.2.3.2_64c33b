<?php session_start(); ?>
<?php
    require_once("common.php");
    
    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    $process_ok = false;
    $edit_mode = 1; // 1 : insert , 2 : update

    if (isset($_POST["dbf_id"])) {
        $edit_mode = 2;
    }
    /////////////////////////////////////////////////////////////////////////
    require_once("DB_config.php");
    require_once("DB_class.php");
    /////////////////////////////////////////////////////////////////////////
    $db = new DB();
    $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    /////////////////////////////////////////////////////////////////////////
    if (!$db->check_priv($_SESSION['user_id'], 'priv_account')) {
        $db->close();
        include('access_denied.php');
        return;
    }
    /////////////////////////////////////////////////////////////////////////
    if ($edit_mode == 2) $dbf_id = $db->escape_string($_POST['dbf_id']);
    $dbf_account_id = $db->escape_string($_POST['dbf_account_id']);
    $dbf_account_password = $db->escape_string($_POST['dbf_account_password']);
    $dbf_name = $db->escape_string($_POST['dbf_name']);
    $dbf_email = $db->escape_string($_POST['dbf_email']);
    $dbf_job_name = $db->escape_string($_POST['dbf_job_name']);
    $dbf_phone = $db->escape_string($_POST['dbf_phone']);
    $dbf_mobile_phone = $db->escape_string($_POST['dbf_mobile_phone']);
    $dbf_memo = $db->escape_string($_POST['dbf_memo']);
    
    $dbf_priv_push_notification = ($db->escape_string($_POST['dbf_priv_push_notification']) == 'on' ? 1 : 0);
    $dbf_priv_address_book = ($db->escape_string($_POST['dbf_priv_address_book']) == 'on' ? 1 : 0);
    
    $dbf_priv_account = ($db->escape_string($_POST['dbf_priv_account']) == 'on' ? 1 : 0);

    if ($edit_mode == 1) { // insert
        $sql = 
                "INSERT INTO account ".
                "(account_id,account_password,valid,name,email,job_name,phone,mobile_phone,memo,".
                " priv_push_notification,priv_address_book,priv_account,".
                " create_user_id,create_date,modi_date) ".
                "VALUES(".
                "'$dbf_account_id',".
                "'$dbf_account_password',".
                "'1',".
                "'$dbf_name',".
                "'$dbf_email',".
                "'$dbf_job_name',".
                "'$dbf_phone',".
                "'$dbf_mobile_phone',".
                "'$dbf_memo',".
                "$dbf_priv_push_notification,".
                "$dbf_priv_address_book,".
                "$dbf_priv_account,".
                $_SESSION['user_id'].",".
                "now(),".
                "now()".
                ")";
    } else if ($edit_mode == 2) { // update
        $sql = 
                "UPDATE account SET ".
                "account_id='$dbf_account_id',".
                "account_password='$dbf_account_password',".
                "valid=1,".
                "name='$dbf_name',".
                "email='$dbf_email',".
                "job_name='$dbf_job_name',".
                "phone='$dbf_phone',".
                "mobile_phone='$dbf_mobile_phone',".
                "memo='$dbf_memo',".
                "priv_push_notification=$dbf_priv_push_notification,".
                "priv_address_book=$dbf_priv_address_book,".
                "modi_date=now() ".
                "WHERE id=$db->escape_string($dbf_id)";
    } else {
        die('系統錯誤!!!');
    }

    if ($db->query($sql)) {
        echo "變更完成....";
        $process_ok = true;
    } else {
        die('系統錯誤!!!');
    }
    /////////////////////////////////////////////////////////////////////////

    if (!isset($_GET["page"])) {
        $page = 1;
    } else {
        $page = intval($_GET["page"]);
    }
    /////////////////////////////////////////////////////////////////////////
    $db->close();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
</head>
<body>
<script type="text/javascript">
    $(document).ready(function () {
<?php 
        if ($process_ok) {
            echo "var url = 'account_list.php?page=$page';";
            echo "window.location.href = url;";
        }
?>
    });	
</script>
</body>
</html>