<?php session_start(); ?>
<?php
    require_once("common.php");

    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    /////////////////////////////////////////////////////////////////////////
    if (!isset($_GET["page"])) {
    	$page = 1;
    } else {
    	$page = intval($_GET["page"]);
    }
    
    $title_desc = "推播管理";
    $edit_mode_id_not_found = false;
    /////////////////////////////////////////////////////////////////////////
    if (isset($_GET["id"])) {
    	require_once("DB_config.php");
    	require_once("DB_class.php");
	/////////////////////////////////////////////////////////////////////////
    	$db = new DB();
        $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
        /////////////////////////////////////////////////////////////////////////
        if (!$db->check_priv($_SESSION['user_id'], 'priv_push_notification')) {
            $db->close();
            include('access_denied.php');
            return;
        }
        /////////////////////////////////////////////////////////////////////////
        $id = $_GET["id"];
    	$sql = "SELECT * FROM device_token WHERE id=".$db->escape_string($id);
    	$db->query($sql);
    	
    	if (($result = $db->fetch_array())) {
            $dbf_plateform = $result['plateform'];
            $dbf_sip_account = $result['sip_account'];
            $dbf_device_id = $result['device_id'];
            $dbf_token_id = $result['token_id'];
    	} else {
            $edit_mode_id_not_found = true;
    	}
    	
    	$db->close();
    }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
    <link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>	   
<form id="form" method="post" enctype="multipart/form-data">
    <table width="100%" align="left" cellpadding="5px" cellspacing="0" style="margin-top:2px; margin-bottom: 10px; border:2px #D8D8D8 solid;padding:5px;" rules="all" cellpadding="5">
        <tr>
            <td colspan='2'><h1><?php echo $title_desc; ?></h1></td>
        </tr>
        <tr>
            <td align="center">編號</td>
            <td>
<?php 
    if (empty($id)) {
        echo "<font style='color:#0000FF;'>系統自動編號</font>";
    } else {
        echo $id;
        echo '<input type="hidden" id="dbf_id" name="dbf_id" value="'.$id.'"></input>';
    }
?>
            </td>
        </tr>
        <tr>
            <td align="center"><font style='color:red;'>*</font>標題</td>
            <td>
                <input type="text" id="dbf_subject" name="dbf_subject" maxlength="100" value="<?php echo $dbf_subject; ?>" style="width:100%;"></input>
            </td>
        </tr>
        <tr>
            <td align="center"><font style='color:red;'>*</font>內容</td>
            <td style="padding:5px;" cellpadding='0'>
                <textarea id="dbf_content" name="dbf_content" maxlength="500" cols="80" rows="5"><?php echo $dbf_content; ?></textarea>
            </td>
        </tr>
        <tr>
            <td style='text-align: center;' colspan='2'>
                <button type="button" id="submit_button" name="submit_button" style="margin-right: 50px;">確定存檔</button>
                <button type="button" id="cancel_button" name="cancel_button">回上一頁</button>
            </td>
        </tr>
    </table>
</form>
<script type="text/javascript">
    $(document).ready(function () {
<?php 
    if ($edit_mode_id_not_found) {
        echo "var url = 'push_notification_list.php?page=<?php echo $page; ?>';";
        echo "window.location.href = url;";
    }
?>
        $("#submit_button").click(function() {
            var type = $('input:radio:checked[name="dbf_type"]').val();

            if (typeof type == 'undefined') {
                alert('請輸入[種類]');
                return false;
            }
            if (!$.trim($("#dbf_subject").val()).length) {
                alert('請輸入[標題]');
                $("#dbf_subject").focus();
                return false;
            }
            if (!$.trim($("#dbf_content").val()).length) {
                alert('請輸入[內容]');
                $("#dbf_content").focus();
                return false;
            }

            $("#submit_button").html('處理中請稍候...');
            $("#submit_button").attr('disabled', true);
            $("#cancel_button").attr('disabled', true);

            $("#form").attr("action", "push_notification_update.php?page=<?php echo $page; ?>");
            $("#form").submit();
            return true;
        });

        $("#cancel_button").click(function() {
            window.history.back();
        });
    });
</script>
</body>
</html>