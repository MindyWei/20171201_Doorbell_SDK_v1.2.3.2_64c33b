
<?php
	$account_id = $_GET["account_id"];
	$url = "https://127.0.0.1:5050/PushSipAccount?from_account=service&to_account=".$account_id."&auth_code=123";
	echo $url;
	
    $xml = file_get_contents($url);

    echo $xml;
?>
