<?php session_start(); ?>
<?php
    require_once("common.php");

    if (!check_logon()) {
        include('logon.php');
        return;
    }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link href="admin_style.css" rel="stylesheet" type="text/css">
</head>
<body>
    <p style="font-size:30px; color:#FF0000; width:100%; text-align:center;">權限不足，存取被拒</p>
</body>
</html>

