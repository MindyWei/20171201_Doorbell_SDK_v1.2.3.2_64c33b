<?php
    session_start();
    $_SESSION = array();
?>
<?php
    require_once("common.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
    <title><?php echo project_name(); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="description" content="Expand, contract, animate forms with jQuery wihtout leaving the page" />
    <meta name="keywords" content="expand, form, css3, jquery, animate, width, height, adapt, unobtrusive javascript"/>
    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <script src="js/cufon-yui.js" type="text/javascript"></script>
    <script src="js/ChunkFive_400.font.js" type="text/javascript"></script>
</head>
<body>
    <div class="wrapper">
        <div class="content">
            <div id="form_wrapper" class="form_wrapper">
                <form class="login active">
                    <h3><?php echo project_name(); ?></h3>
                    <div>
                        <label>帳號:</label>
                        <input id="account_id" name="account_id" type="text" />
                        <span class="error">This is an error</span>
                    </div>
                    <div>
                        <label>密碼:</label>
                        <input id="account_password" name="account_password" type="password" />
                        <span class="error">This is an error</span>
                    </div>
                    <div class="bottom">
                        <input type="submit" id="submit_button" name="submit_button" value="登入"></input>
                        <div class="clear"></div>
                    </div>
                </form>
            </div>
            <div class="clear"></div>
        </div>
    </div>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#account_id").focus();

        $("#submit_button").click(function() {
            var _account_id = $.trim($("#account_id").val());
            var _account_password = $.trim($("#account_password").val());

            if (!_account_id.length) {
                alert('請輸入[帳號]');
                $("#account_id").focus();
                return false;
            }
            if (!_account_password.length) {
                alert('請輸入[密碼]');
                $("#account_password").focus();
                return false;
            }

            $("#submit_button").html('處理中請稍候...');
            $("#submit_button").attr('disabled', true);

            $.post( "do_logon.php", { account_id: _account_id, account_password: _account_password })
                .done(function( data ) {
                    if (data == "1") {
                        var url = 'index.php';
                        window.location.href = url;
                    } else {
                        alert( "[帳號或密碼]錯誤，請再檢查一次" );
                        $("#account_password").focus();

                        $("#submit_button").html('登入');
                        $("#submit_button").attr('disabled', false);
                    }
                }).
                fail(function() {
                    alert( "error" );
                });

            return false;
        });
    });
</script>
    </body>
</html>