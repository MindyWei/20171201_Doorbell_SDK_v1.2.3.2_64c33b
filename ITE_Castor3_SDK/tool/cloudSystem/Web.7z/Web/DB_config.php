<?php
    global $_DB;	
    $_DB['host'] = "127.0.0.1";//"syscodevoip.duckdns.org";
    $_DB['username'] = "root";
    $_DB['password'] = "voip27295344";
    $_DB['dbname'] = "app_extra_service";
    
    global $mysqli;
    $mysqli = new mysqli($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    
    if ($mysqli->connect_errno) {
    	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }
?>
