<?php

class DB 
{
    var $_dbConn = 0;
    var $_queryResource = 0;
    
    function DB() {
        //do nothing
    }
    
    function connect_db($host, $user, $pwd, $dbname) {
        $dbConn = mysql_connect($host, $user, $pwd);
        if (!$dbConn) {
            die ("MySQL Connect Error");
        }
        mysql_query("SET NAMES utf8");
		mysql_query('SET CHARACTER SET utf8');
        if (!mysql_select_db($dbname, $dbConn)) {
            die ("MySQL Select DB Error");
        }
        $this->_dbConn = $dbConn;

        return true;
    }
    
    function query($sql) {
        if (!$queryResource = mysql_query($sql, $this->_dbConn)) {
            die ("MySQL Query Error");
        }
        $this->_queryResource = $queryResource;
        return $queryResource;
    }
    
    function escape_string($val) {
    	//return mysqli_real_escape_string($this->_dbConn, $val);
    	return mysql_real_escape_string($val);
    }
    
    function get_num_rows() {
        return mysql_num_rows($this->_queryResource);
    }
    
    function close() {
    	mysql_close($this->_dbConn);
    }
    
    /** Get array return by MySQL */
    function fetch_array() {
        return mysql_fetch_array($this->_queryResource, MYSQL_ASSOC);
    }
    
    function check_priv($user_id, $priv_name) {
		//$sql = "SELECT ".$priv_name." FROM account WHERE id=".$user_id." AND ".$priv_name."=1";
        $sql = "SELECT ".$priv_name." FROM account WHERE id=".$user_id." AND ".$priv_name."=1";
		$this->query($sql);
		
		$result = false;
		
		if (($result2255 = $this->fetch_array())) {
            //if ($result2255[$priv_name] == 1) {
                $result = true;
            //}
		}
		
		return $result;
    }
    
    function get_account_name($account_id) {
        $sql = "SELECT name FROM account WHERE account_id='".$account_id."';";
		$this->query($sql);
		
		$result = false;
        $name = '';
		
		if (($result8877 = $this->fetch_array())) {
            $name = $result8877[name];
		}
		
		return $name;
    }
    
    function delete_all_address_book() {
        $sql = "DELETE FROM address_book;";
		$this->query($sql);
    }

    function update_address_book_version() {
        $sql = "UPDATE configuration SET content=unix_timestamp(now()),modi_date=now() WHERE name='ADDRESS_BOOK_MODI_DATE';";
		$this->query($sql);
    }

    function update_address_book_gateway($value) {
        $sql = "UPDATE configuration SET content='".$this->escape_string($value)."' WHERE name='ADDRESS_BOOK_GATEWAY';";
		$this->query($sql);
    }
    
    function update_address_book_submask($value) {
        $sql = "UPDATE configuration SET content='".$this->escape_string($value)."' WHERE name='ADDRESS_BOOK_SUBMASK';";
		$this->query($sql);
    }
    
    function insert_address_book($ty,$alias,$ro,$_group,$mc,$ip,$user_id,$user_pwd) {
        $sql = 
        	"INSERT INTO address_book (".
        	"ty,alias,ro,_group,mc,ip,user_id,user_pwd,reg_date,modi_date".
        	")VALUES(".
        	"'".$this->escape_string($ty)."',".
        	"'".$this->escape_string($alias)."',".
        	"'".$this->escape_string($ro)."',".
        	"'".$this->escape_string($_group)."',".
        	"'".$this->escape_string($mc)."',".
        	"'".$this->escape_string($ip)."',".
        	"'".$this->escape_string($user_id)."',".
        	"'".$this->escape_string($user_pwd)."',".
        	"now(),now());";
		$this->query($sql);
    }
}

?>
