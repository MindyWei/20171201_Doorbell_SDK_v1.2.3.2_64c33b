<?php session_start(); ?>
<?php
    require_once("common.php");

    if (!check_logon()) {
        include('index.php');
        return;
    }
?>
<?php
    $process_ok = false;

    $edit_mode = 1; // 1 : insert , 2 : update

    if (isset($_POST["dbf_id"])) {
        $edit_mode = 2;
    }
    /////////////////////////////////////////////////////////////////////////
    require_once("DB_config.php");
    require_once("DB_class.php");
    /////////////////////////////////////////////////////////////////////////
    $db = new DB();
    $db->connect_db($_DB['host'], $_DB['username'], $_DB['password'], $_DB['dbname']);
    /////////////////////////////////////////////////////////////////////////
    if (!$db->check_priv($_SESSION['user_id'], 'priv_address_book')) {
        $db->close();
        include('access_denied.php');
        return;
    }
    /////////////////////////////////////////////////////////////////////////
    if ($edit_mode == 2) $dbf_id = $db->escape_string($_POST['dbf_id']);
    
	$dbf_ty = $db->escape_string($_POST['dbf_ty']);
	$dbf_alias = $db->escape_string($_POST['dbf_alias']);
	$dbf_ro = $db->escape_string($_POST['dbf_ro']);
	$dbf_group = $db->escape_string($_POST['dbf_group']);
	$dbf_mc = $db->escape_string($_POST['dbf_mc']);
	$dbf_ip = $db->escape_string($_POST['dbf_ip']);
	$dbf_user_id = $db->escape_string($_POST['dbf_user_id']);
	$dbf_user_pwd = $db->escape_string($_POST['dbf_user_pwd']);

    if ($edit_mode == 1) { // insert
        $sql = 
                "INSERT INTO address_book ".
                "(ty,alias,ro,_group,mc,ip,user_id,user_pwd,reg_date,modi_date) ".
                "VALUES(".
                "'$dbf_ty',".
                "'$dbf_alias',".
                "'$dbf_ro',".
                "'$dbf_group',".
                "'$dbf_mc',".
                "'$dbf_ip',".
                "'$dbf_user_id',".
                "'$dbf_user_pwd',".
                "now(),now()".
                ")";
    } else if ($edit_mode == 2) { // update
        $sql = 
                "UPDATE address_book SET ".
                "ty='$dbf_ty',".
                "alias='$dbf_alias',".
                "ro='$dbf_ro',".
                "_group='$dbf_group',".
                "ip='$dbf_ip',".
                "user_id='$dbf_user_id',".
                "user_pwd='$dbf_user_pwd',".
                "modi_date=now() ".
                "WHERE id=$dbf_id";
    } else {
        die('系統錯誤!!!');
    }

    if ($db->query($sql)) {
        echo "變更完成....";
        $process_ok = true;
    } else {
        die('系統錯誤!!!');
    }
    
    $sql = "UPDATE configuration SET content=unix_timestamp(now()),modi_date=now() WHERE name='ADDRESS_BOOK_MODI_DATE';";
	if ($db->query($sql)) {
        echo "變更完成....";
        $process_ok = true;
    } else {
        die('系統錯誤!!!');
    }

    /////////////////////////////////////////////////////////////////////////

    if (!isset($_GET["page"])) {
        $page = 1;
    } else {
        $page = intval($_GET["page"]);
    }
    /////////////////////////////////////////////////////////////////////////
    $db->close();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <script src="jquery.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <META name="viewport" content="width=device-width; initial-scale=1.0">
</head>
<body>
<script type="text/javascript">
    $(document).ready(function () {
<?php 
        if ($process_ok) {
            echo "var url = 'address_book.php?page=$page;';";
            echo "window.location.href = url;";
        }
?>
    });	
</script>
</body>
</html>