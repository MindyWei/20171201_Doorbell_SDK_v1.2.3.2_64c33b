<?php
    function check_logon() {
        if (empty($_SESSION['user_id']) || empty($_SESSION['user_account_id'])) {
            return false;
        } else {
            return true;
        }
    }
    
    function project_name() {
        return "iTE Intercom Menagement";
    }
    
    function getMD5Key() {
        return "ITE_INTERCOM_KEY_201508012";
    }
    
    function filter_string($subject, $filter) {
        return str_replace($filter, "<font color='red'>".$filter."</font>", $subject);
    }
?>
