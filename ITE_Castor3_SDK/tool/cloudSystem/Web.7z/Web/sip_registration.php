<?php
    echo '{"result":200, "sip_account":"7002", "sip_password":"ite7002"}';
?>
